console.log('Funcionando ando');

let elChicken = $('#chicken');
let bbyYoda = $('#bbyoda');
let steveAttack = $('#steve');
let laTnt = $('#tnt');

// Chicken Jockey
function desaparece() {
    elChicken.remove();
    console.log('El pollo desapareció');
}

// Dialogo Steve
function dialoga() {
    let mensaje = ('Arriba las manos flaco');
    let popover = new bootstrap.Popover(steveAttack[0], {
        content: mensaje,
        trigger: 'manual', // Para que se mostrara al hacer clic
        placement: 'top', // Donde aparecerá el popover relativo al elemento (top, bottom, left, right, auto)
        title: 'El Steve dice:'
    });
    popover.show();

    // Para que se cierre automaticamente en 3 segundos
    setTimeout(function() {
        popover.hide();
    }, 3000);

    console.log('Steve habló');
}

// Movimiento Baby Yoda
function arriba() {
    let bbyYoda = $('#bbyoda');
    bbyYoda.animate({
        top: '-=20px' // Mueve 20 píxeles hacia arriba
    }, 200); // Duración de la animación en milisegundos
}

function abajo() {
    let bbyYoda = $('#bbyoda');
    bbyYoda.animate({
        top: '+=20px' // Mueve 20 píxeles hacia abajo
    }, 200); // Duración de la animación en milisegundos
}

function derecha() {
    let bbyYoda = $('#bbyoda');
    bbyYoda.animate({
        left: '+=20px' // Mueve 20 píxeles hacia la derecha
    }, 200); // Duración de la animación en milisegundos
}

function izquierda() {
    let bbyYoda = $('#bbyoda');
    bbyYoda.animate({
        left: '-=20px' // Mueve 20 píxeles hacia la izquierda
    }, 200); // Duración de la animación en milisegundos
}

function sugerencia() {
    let mensaje = ('Para detonar haz doble click')
    let popover = new bootstrap.Popover(laTnt[0], {
        content: mensaje,
        trigger: 'manual',
        placement: 'top', 
    });
    popover.show();

    setTimeout(function() {
        popover.hide();
    }, 1000);
}

// Detonación de la TNT
function explota() {
    laTnt.remove();

    let nada = $('body');
    nada.text('Haz destruido este mundo, el olor a carne quemada impregno el ambiente');
    nada.append('<br><br><button id="reiniciar">Restaurar Mundo</button>');
    nada.addClass('container texto-e');

    alert('La TNT hizo KBOOM!!');
    console.log('Haz detonado la TNT!!');

    $('#reiniciar').on('click', function() {
        location.reload(); // Recarga la página
        console.log('Haz restaurado el mundo que acabas de destruir');
    })
}